import tkinter as tk
from tkinter import ttk
from Modelo import *

# Función para mostrar el frame seleccionado
def show_frame(selected_frame):
    for frame in frames.values():
        frame.pack_forget()
    frames[selected_frame].pack(fill=tk.BOTH, expand=True)

# Crear la ventana principal
root = tk.Tk()
root.title("Selector Dinámico de Frames")


# Crear el frame principal
main_frame = ttk.Frame(root, padding="10")
main_frame.pack(fill=tk.BOTH, expand=True)

# Crear el frame de control para el Combobox
control_frame = ttk.Frame(main_frame, padding="10")
control_frame.pack(side=tk.TOP, fill=tk.X)

# Variable para almacenar la selección del Combobox
selected_frame = tk.StringVar()

# Crear Combobox para seleccionar el frame
frame_selector = ttk.Combobox(control_frame, textvariable=selected_frame)
frame_selector['values'] = ("Enfermedad", "Paciente", "Frame C")
frame_selector.current(0)  # Seleccionar el primer frame por defecto
frame_selector.pack(side=tk.LEFT, padx=5)

# Crear diccionario para almacenar los frames
frames = {}

# Crear Frame A
frames['Enfermedad'] = FrEnfermedad(main_frame)

# Crear Frame B
frames["Paciente"] = FrPaciente(main_frame)

# Crear Frame C (opcional, para mostrar más opciones dinámicas)
frames["Frame C"] = ttk.Frame(main_frame, padding="10", relief=tk.RIDGE, borderwidth=2)
label_c = ttk.Label(frames["Frame C"], text="Este es el Frame C")
label_c.pack(pady=10)

# Asociar el evento de selección del Combobox con la función show_frame
frame_selector.bind("<<ComboboxSelected>>", lambda event: show_frame(selected_frame.get()))

# Mostrar el frame A inicialmente
show_frame("Enfermedad")

# Ejecutar el bucle principal de la aplicación
root.mainloop()