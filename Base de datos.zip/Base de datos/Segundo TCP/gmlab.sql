CREATE DATABASE  IF NOT EXISTS `gmlab` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `gmlab`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: gmlab
-- ------------------------------------------------------
-- Server version	5.5.5-10.3.16-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `enfermedad`
--

DROP TABLE IF EXISTS `enfermedad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enfermedad` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(245) DEFAULT NULL,
  `sintomas` varchar(250) DEFAULT NULL,
  `descubridor` varchar(50) DEFAULT NULL,
  `anno_aparicion` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enfermedad`
--

LOCK TABLES `enfermedad` WRITE;
/*!40000 ALTER TABLE `enfermedad` DISABLE KEYS */;
INSERT INTO `enfermedad` VALUES (1,'Dengue','Fiebre, dolor de cabeza, dolor muscular y articular, erupciones cutáneas','Benjamin Rush',1900),(2,'Alzheimer','Pérdida de memoria, desorientación, cambios de humor, dificultades para realizar tareas cotidianas','Alois Alzheimer',2000),(3,'Diabetes tipo 1','Aumento de la sed, micción frecuente, fatiga, pérdida de peso','Thomas Willis',1700),(4,'Tuberculosis','Tos persistente, fiebre, sudoración nocturna, pérdida de peso','Robert Koch',1900),(5,'VIH/SIDA',' Infecciones oportunistas, pérdida de peso, fatiga, fiebre','Luc Montagnier y Robert Gallo',1980),(6,'Cancer ','Tos persistente, dificultad para respirar, dolor en el pecho, perdidad de peso inexplicada ','Dr.Ernst Wynder',1800),(7,'Hipertension Arterial','Dolor de ccabeza, vision borrosa, fatiga, dificultad para respirar','Dr.Frederick Mahomed',1900),(8,'Parkinson','Temblores, rápidez muscular, bradicinesia','James Parkinson',1817),(9,'Gripe Española ','Fiebre, tos, dolor de garganta ','Anónimo',1918),(10,'Varicela ','Erupciones cutaneas con ampollas que causan picazón','Thomas Weller',1958),(17,'nombre','sintomas','descubridor',0);
/*!40000 ALTER TABLE `enfermedad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ensayo_clinico`
--

DROP TABLE IF EXISTS `ensayo_clinico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ensayo_clinico` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(250) DEFAULT NULL,
  `objetivo` varchar(250) DEFAULT NULL,
  `fecha_inicio` date DEFAULT NULL,
  `fecha_final` date DEFAULT NULL,
  `descripcion` varchar(1000) DEFAULT NULL,
  `enfermedad_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ID_UNIQUE` (`id`),
  KEY `fk_ensayo_clinico_enfermedad1_idx` (`enfermedad_id`),
  CONSTRAINT `fk_ensayo_clinico_enfermedad1` FOREIGN KEY (`enfermedad_id`) REFERENCES `enfermedad` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ensayo_clinico`
--

LOCK TABLES `ensayo_clinico` WRITE;
/*!40000 ALTER TABLE `ensayo_clinico` DISABLE KEYS */;
INSERT INTO `ensayo_clinico` VALUES (1,'Estudio de Vacuna Preventiva contra el Dengue','Evaluar la eficacia de una vacuna experimental en la prevención del dengue en zonas endémicas.','2023-07-05','2024-12-31','Este ensayo de fase III se llevará a cabo en colaboración con comunidades afectadas por el dengue para evaluar la seguridad y eficacia de la vacuna en la prevención de la enfermedad.',1),(2,'Investigación de Terapias Innovadoras para el Alzheimer','Evaluar el impacto de una nueva terapia en la progresión de la enfermedad de Alzheimer en pacientes en etapas tempranas.','2023-01-10','2025-12-31',' Este ensayo longitudinal incluye pruebas cognitivas y escáneres cerebrales para investigar cómo la terapia propuesta puede afectar el deterioro cognitivo en pacientes con Alzheimer leve.',2),(3,'Estudio de Tratamiento Efectivo para la Diabetes Tipo 1','Evaluar la eficacia de un nuevo tratamiento en el control de la glucosa en pacientes con diabetes tipo 1.','2023-03-01','2024-09-30','Este ensayo clínico aleatorizado controlado por placebo involucra a 100 participantes con diabetes tipo 1 para investigar la seguridad y eficacia de un fármaco oral en el control de la glucosa.',3),(4,'Investigación de Terapias Avanzadas para el VIH/SIDA','Evaluar el impacto de terapias avanzadas en la carga viral y la calidad de vida de pacientes con VIH/SIDA.','2022-09-01','2024-06-30','Este ensayo clínico contará con la participación de pacientes con diferentes perfiles de resistencia para investigar cómo las terapias genéticas pueden reducir la carga viral y mejorar la calidad de vida de los pacientes con VIH/SIDA.',5),(5,'Estudio de Ejercicio Físico en la Gestión de la Diabetes Tipo 2',' Investigar el impacto del ejercicio físico regular en el control glucémico y la calidad de vida de pacientes con diabetes tipo 2.','2023-04-01','2025-03-31','Este ensayo clínico aleatorizado controlado por grupos paralelos examinará a 150 participantes con diabetes tipo 2 para evaluar los efectos del ejercicio aeróbico y de resistencia en la reducción de la glucosa en sangre y en la mejoría de los marcadores de salud cardiovascular. Los participantes serán divididos en tres grupos: un grupo realizará ejercicio aeróbico, otro grupo realizará ejercicio de resistencia, y un grupo de control recibirá orientación sobre hábitos saludables sin ejercicio estructurado.',3),(6,'Estudio sobre hipertensión arterial','Investigar el impacto de una nueva cura para la hipertension arterial','2023-05-12','2025-03-05','Este ensayo es para investigar la efectividad de la nueva cura',7),(7,'Estudio sobre el cancer','Investigar el impacto de una nueva cura para el cancer','2023-06-05','2025-06-08','Este ensayo es para investigar la efectividad de la cura',6),(8,'Estudio sobre hipertensión arterial 2','Investigar el impacto de una nueva cura para la hipertension arterial','2022-06-15','2023-03-05','Este ensayo es para investigar la efectividad de la nueva cura',7),(9,'Estudio sobre el cancer 2','Investigar el impacto de una nueva cura para el cancer','2023-08-02','2024-06-08','Este ensayo es para investigar la efectividad de la cura',6),(10,'Estudio sobre cancer 3','Investigar el impacto de una nueva cura para el cancer','2022-08-15','2024-06-09','Este ensayo es para investigar la efectividad de la cura',6);
/*!40000 ALTER TABLE `ensayo_clinico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `especialidad`
--

DROP TABLE IF EXISTS `especialidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `especialidad` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(250) DEFAULT NULL,
  `descripcion` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `especialidad`
--

LOCK TABLES `especialidad` WRITE;
/*!40000 ALTER TABLE `especialidad` DISABLE KEYS */;
INSERT INTO `especialidad` VALUES (1,'Cardiología Intervencionista','La cardiología intervencionista es una subespecialidad de la cardiología que se enfoca en el tratamiento invasivo de las enfermedades cardiovasculares. Los cardiólogos intervencionistas realizan procedimientos como cateterismos cardíacos, angioplastias y colocación de stents para tratar enfermedades coronarias, obstrucciones en las arterias y otras afecciones cardíacas que requieren intervenciones más avanzadas.'),(2,'Dermatología Oncológica','La dermatología oncológica es una subespecialidad de la dermatología que se centra en el diagnóstico y tratamiento de cánceres de piel y otras neoplasias cutáneas. Los dermatólogos oncológicos están especializados en la detección temprana del cáncer de piel, la realización de biopsias cutáneas, la cirugía de Mohs para la extirpación de tumores cutáneos y el seguimiento de pacientes con antecedentes de cáncer de piel. Trabajan en equipos multidisciplinarios junto con oncólogos, cirujanos y otros especialistas para brindar un enfoque integral en el tratamiento del cáncer cutáneo.'),(3,' Neumología Pediátrica','La neumología pediátrica es una subespecialidad de la neumología que se dedica al diagnóstico y tratamiento de enfermedades respiratorias en niños y adolescentes. Los neumólogos pediátricos tratan afecciones como el asma infantil, la bronquiolitis, las malformaciones pulmonares congénitas y otras enfermedades pulmonares que afectan a la población pediátrica. Trabajan en estrecha colaboración con pediatras y otros especialistas para brindar atención integral a los pacientes más jóvenes.'),(4,'nombre','descripcion');
/*!40000 ALTER TABLE `especialidad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `historia_clinica`
--

DROP TABLE IF EXISTS `historia_clinica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `historia_clinica` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_creacion` date DEFAULT NULL,
  `descripcion` varchar(250) DEFAULT NULL,
  `Paciente_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`Paciente_id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `fk_historia_clinica_Paciente1_idx` (`Paciente_id`),
  CONSTRAINT `fk_historia_clinica_Paciente1` FOREIGN KEY (`Paciente_id`) REFERENCES `paciente` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `historia_clinica`
--

LOCK TABLES `historia_clinica` WRITE;
/*!40000 ALTER TABLE `historia_clinica` DISABLE KEYS */;
INSERT INTO `historia_clinica` VALUES (1,'2022-09-04','María padece de dengue.',1),(2,'2021-05-11','Juan padece de dengue.',2),(3,'2020-12-07','Ana padece de Alzheimer.',3),(4,'2023-03-03','Pedro padece de diabetes tipo 1',4),(5,'2019-10-09','Laura padece de VIH/SIDA.',5),(6,'2020-05-12','Ana padece de cancer',6),(7,'2018-03-07','Elena padece de hipertensión ',7),(8,'2017-07-12','Patricia padece de cancer',8),(9,'2016-05-08','Laura Péres padece de hipertensión',9),(10,'2015-06-05','Filomena padece de hipertensión',10);
/*!40000 ALTER TABLE `historia_clinica` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medico`
--

DROP TABLE IF EXISTS `medico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medico` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ci` varchar(11) DEFAULT NULL,
  `nombre_y_apellidos` varchar(250) DEFAULT NULL,
  `sexo` char(1) DEFAULT NULL,
  `annos_experiencia` int(11) DEFAULT NULL,
  `ensayo_clinico_id` int(11) NOT NULL,
  `especialidad_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `fk_medico_ensayo_clinico1_idx` (`ensayo_clinico_id`),
  KEY `fk_medico_especialidad1_idx` (`especialidad_id`),
  CONSTRAINT `fk_medico_ensayo_clinico1` FOREIGN KEY (`ensayo_clinico_id`) REFERENCES `ensayo_clinico` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_medico_especialidad1` FOREIGN KEY (`especialidad_id`) REFERENCES `especialidad` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medico`
--

LOCK TABLES `medico` WRITE;
/*!40000 ALTER TABLE `medico` DISABLE KEYS */;
INSERT INTO `medico` VALUES (1,'12345678901','Ana García López','f',10,1,1),(2,'23456789012','Juan Rodríguez Martínez ','m',8,2,3),(3,'34567890123','Maria Fernández Ruiz','f',12,3,2),(4,'45678901234','Pedro Sánchez González','m',15,1,1),(5,'56789012345','Laura Pérez García','f',6,1,3),(7,'54876565412','Genaro Lopez Brito','m',7,10,2),(8,'45486887891','Yenifer Ramos Arias','f',9,10,3),(9,'21568795462','Josefina Kuka Kimbo','f',5,10,1),(10,'56489798165','Alan Brito Prieto','m',2,10,2);
/*!40000 ALTER TABLE `medico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paciente`
--

DROP TABLE IF EXISTS `paciente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paciente` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ci` varchar(11) DEFAULT NULL,
  `nombre_y_apellidos` varchar(250) DEFAULT NULL,
  `sexo` char(1) DEFAULT NULL,
  `edad` int(11) DEFAULT NULL,
  `direccion` varchar(100) DEFAULT NULL,
  `Telefono` int(11) NOT NULL,
  `enfermedad_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `Telefono_UNIQUE` (`Telefono`),
  KEY `fk_Paciente_enfermedad1_idx` (`enfermedad_id`),
  CONSTRAINT `fk_Paciente_enfermedad1` FOREIGN KEY (`enfermedad_id`) REFERENCES `enfermedad` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paciente`
--

LOCK TABLES `paciente` WRITE;
/*!40000 ALTER TABLE `paciente` DISABLE KEYS */;
INSERT INTO `paciente` VALUES (1,'12345678901','María García Pérez','f',30,'Calle Primavera, 123',458769325,1),(2,'98765432101','Juan Rodríguez López','m',45,'Avenida Libertad, 456',459835164,1),(3,'56789012301','Ana Martínez Ruiz','f',25,'Calle Esperanza, 789',847559356,2),(4,'01234567890','Pedro Fernández Gómez','m',35,'Plaza Principal, 101',846532158,3),(5,'23456789012','Laura Sánchez Martín','f',28,'Avenida Central, 222',254628139,5),(6,'12345678901','Ana Martínez García','f',57,'Calle Primavera,564',543218567,6),(7,'23456780125','Elena Rodríguez López','f',60,'Avenida Sol, 456',153245678,7),(8,'85461381752','Patricia Gómez Fernández','f',65,'Paseo de la luna, 789',156548799,6),(9,'84656516575','Laura Pérez Ruiz','f',70,'Plaza Mayor, 102',865487962,7),(10,'45687815347','Filomena Basques Basques ','f',64,'Avenida unicornio, 205',456812354,7);
/*!40000 ALTER TABLE `paciente` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-25 13:12:54
