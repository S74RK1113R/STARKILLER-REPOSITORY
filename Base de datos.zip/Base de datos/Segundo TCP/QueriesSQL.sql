INSERT INTO `gmlab`.`medico` (`id`, `ci`, `nombre_y_apellidos`, `sexo`, `annos_experiencia`, `ensayo_clinico_id`, `especialidad_id`) 
VALUES ('11', '56486486799', 'Juan Lopez Gonzales ', 'm', '3', '2', '3');

UPDATE `gmlab`.`medico` SET `sexo` = 'f' WHERE (`id` = '11');

DELETE FROM `gmlab`.`medico` WHERE (`id` = '11');

select ensayo_clinico.nombre as "Estudio Clinico",
enfermedad.nombre as "Enfermedad", count(DISTINCT medico.id) as "Numero de medicos",
COUNT(DISTINCT paciente.id) as "Cantidad de pacientes"
from ensayo_clinico
left join enfermedad on enfermedad.id = ensayo_clinico.enfermedad_id
left join paciente on paciente.enfermedad_id = enfermedad.id
left join medico on medico.ensayo_clinico_id = ensayo_clinico.id
group by ensayo_clinico.id


select nombre_y_apellidos as "Nombre del paciente", 
edad "Edad del paciente", 
enfermedad.nombre "Enfermedad que padece" 
from paciente
inner join enfermedad on enfermedad.id = paciente.enfermedad_id
where sexo = "f" and edad >= 57 and edad <=70 and paciente.enfermedad_id = 6
order by nombre_y_apellidos ASC


select 
ci, nombre_y_apellidos, sexo, edad
direccion, telefono, enfermedad.nombre
from paciente
inner join enfermedad on enfermedad.id = paciente.enfermedad_id
where enfermedad.id = "7" and edad > (SELECT AVG(edad) FROM paciente)
