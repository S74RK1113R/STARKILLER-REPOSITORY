import mysql.connector
from Consultas import *

def run_query(query, parametros=()):
    db = mysql.connector.connect(
    host = 'localhost',
    user= 'root',
    password = '',
    database = 'gmlab'
    )
    cursor = db.cursor()
    cursor.execute(query, parametros)
    result = cursor.fetchall()
    db.commit()
    
    cursor.close()
    db.close()
    return result


def get_data(tree, query):
    records =  tree.get_children()
    #Centrando elementos 
    for col in tree['columns']:
        tree.column(col, anchor= 'center')
        
    for element in records:
        tree.delete(element)
        
    db_rows = run_query(query)
    
    for data in db_rows:
        tree.insert('', 'end', values = data)


