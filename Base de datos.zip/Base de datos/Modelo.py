from tkinter import ttk, messagebox
from tkinter import *
from Conections import *
from Consultas import *

class FrEnfermedad(Frame):
    def __init__(self,master = None):
        super().__init__(master)
        self.master = master
        self.pack(fill=BOTH, expand=True, padx= 20, pady=20)
        self.create_widgets()        
        
    def create_widgets(self):
        
        self.enfermedad = Label(self,text= "Enfermedad", font= 'Arial, 15')
        self.enfermedad.pack(side='top', fill= X, expand= True)
        
        self.tree = ttk.Treeview(self,  height= 25, columns= ('ID', 'Nombre', 'Sintomas', 'Descubridor', 'Anno'),show='headings')
        self.tree.heading('ID', text='ID')
        self.tree.heading('Nombre', text='Nombre')
        self.tree.heading('Sintomas', text='Síntomas')
        self.tree.heading('Descubridor', text='Descubridor')
        self.tree.heading('Anno', text='Año de aparición')
        self.tree.pack(fill= X, expand= True, pady=10)

        Button(self,text='Insertar', command= self.insert_form).pack(side= 'left', fill= X, expand= True, padx=5)
        Button(self,text='Editar', command= self.edit_form).pack(side= 'left', fill= X, expand= True, padx=5)
        Button(self,text='Borrar', command= self.erase).pack(side= 'left', fill= X, expand= True, padx=5)

        get_data(self.tree, Consultas.GET_DATA)
        
    def erase(self):
        name = (self.tree.item(self.tree.selection())['values'][0],)
        if name == '':
           messagebox.showwarning(title='Alert', message='Seleccione un elemento')
        else:
            messagebox.showwarning(title='Alert', message='Elemento eliminado')
            run_query(Consultas.ERASE_DATA,name)
            get_data(self.tree, Consultas.GET_DATA)
    
    def insert_form(self):
        self.insert_wind =  Toplevel()
        self.insert_wind.title('Insertar enfermedad') 
        self.insert_wind.geometry('500x500')
        self.insert_wind.resizable(height=False,width=False )
        
        #Variables 
        self.name = StringVar()
        self.afection = StringVar()
        self.discover = StringVar()
        self.anno = StringVar()
        
        self.nombre = Label(self.insert_wind, text= "Nombre: ").pack(expand=True)
        self.nombre_entry = Entry(self.insert_wind,textvariable= self.name).pack(fill = X, padx= 20, pady= 10,expand=True)
        
        self.sintomas = Label(self.insert_wind, text="Sintomas:").pack(expand=True)
        self.sintomas_entry = Entry(self.insert_wind,textvariable= self.afection).pack(fill = X, padx= 20, pady= 10,expand=True)
        
        self.descubridor = Label(self.insert_wind,text="Descubridor:").pack(expand=True)
        self.descubridor_entry = Entry(self.insert_wind,textvariable= self.discover).pack(fill = X, padx= 20, pady= 10,expand=True)
    
        self.anno_aparicion = Label(self.insert_wind, text="Anno aparición:").pack(expand=True)
        self.anno_aparicion_entry = Entry(self.insert_wind,textvariable= self.anno).pack(fill = X, padx= 20, pady= 10,expand=True)    
        
        Button(self.insert_wind, text='Insertar', font='Arial, 10', command=lambda: self.insert_data(
            self.name.get(),self.afection.get(),self.discover.get(),self.anno.get())).pack(side='bottom',fill=X, expand=True, padx=20,pady=20)    
    
    def insert_data(self, name_data , afection_data, discover_data,anno_apear_data):
        self.name_data = name_data
        self.afectiion_data = afection_data
        self.discover_data = discover_data
        self.anno_apear_data = anno_apear_data
        
        values = (self.name_data, self.afectiion_data, self.discover_data, self.anno_apear_data)
        run_query(Consultas.INSERT_DATA, values)
        get_data(self.tree, Consultas.GET_DATA)
        
        self.insert_wind.destroy()
        
    def edit_form(self):
        try:
            id_get = self.tree.item(self.tree.selection())['values'][0]
            name_get = self.tree.item(self.tree.selection())['values'][1]
            afection_get = self.tree.item(self.tree.selection())['values'][2]
            discover_get = self.tree.item(self.tree.selection())['values'][3]
            anno_get = self.tree.item(self.tree.selection())['values'][4]
        except IndexError as e:
            messagebox.showwarning(title='Alert', message='Seleccione un elemento')
            return
        
        self.edit_wind =  Toplevel()
        self.edit_wind.title('Editar enfermedad') 
        self.edit_wind.geometry('500x600')
        
        #Variables 
        self.name = StringVar()
        self.afection = StringVar()
        self.discover = StringVar()
        self.anno = StringVar()
        
        self.nombre = Label(self.edit_wind, text= name_get).pack(expand=True)
        self.nombre_entry = Entry(self.edit_wind,textvariable= self.name).pack(fill = X, padx= 20, pady= 10,expand=True)
        
        self.sintomas = Label(self.edit_wind, text=afection_get).pack(expand=True)
        self.sintomas_entry = Entry(self.edit_wind,textvariable= self.afection).pack(fill = X, padx= 20, pady= 10,expand=True)
        
        self.descubridor = Label(self.edit_wind,text=discover_get).pack(expand=True)
        self.descubridor_entry = Entry(self.edit_wind,textvariable= self.discover).pack(fill = X, padx= 20, pady= 10,expand=True)
    
        self.anno_aparicion = Label(self.edit_wind, text=anno_get).pack(expand=True)
        self.anno_aparicion_entry = Entry(self.edit_wind,textvariable= self.anno).pack(fill = X, padx= 20, pady= 10,expand=True)    
        
        Button(self.edit_wind, text='Editar', font='Arial, 10', command=lambda: self.edit_data(
            self.name.get(),self.afection.get(),self.discover.get(),self.anno.get(),id_get)).pack(side='bottom',fill=X, expand=True, padx=20,pady=20)
        
    def edit_data(self, name_data , afection_data, discover_data,anno_apear_data, id_data):
        self.name_data = name_data
        self.afectiion_data = afection_data
        self.discover_data = discover_data
        self.anno_apear_data = anno_apear_data
        self.id_data = id_data
        
        values = (self.name_data, self.afectiion_data, self.discover_data, self.anno_apear_data, self.id_data)
        run_query(Consultas.UPDATE_ENFERMEDAD, values)
        
        get_data(self.tree, Consultas.GET_DATA)
        self.edit_wind.destroy()
        
class FrPaciente(FrEnfermedad):
    def __init__(self, master=None):
        super().__init__(master)
    
    def create_widgets(self):
        self.paciente = Label(self,text= "Paciente", font= 'Arial, 15')
        self.paciente.pack(side='top', fill= X, expand= True)
        
        self.tree = ttk.Treeview(self,  height= 25, columns= ('ID', 'CI', 'Nombre', 'Sexo', 'Edad','Direccion','Telefono', "Enfermedad_ID"),show='headings')
        self.tree.heading('ID', text='ID')
        self.tree.heading('CI', text='CI')
        self.tree.heading('Nombre', text='Nombre y apellidos')
        self.tree.heading('Sexo', text='Sexo')
        self.tree.heading('Edad', text='Edad')
        self.tree.heading('Direccion', text='Direccion')
        self.tree.heading('Telefono', text='Telefono')
        self.tree.heading('Enfermedad_ID', text='Enfermedad')
        self.tree.pack(fill= X, expand= True, pady=10)

        Button(self,text='Insertar', command=self.insert_form).pack(side= 'left', fill= X, expand= True, padx=5)
        Button(self,text='Editar', command= self.edit_form).pack(side= 'left', fill= X, expand= True, padx=5)
        Button(self,text='Borrar', command= self.erase).pack(side= 'left', fill= X, expand= True, padx=5)

        get_data(self.tree, Consultas.GET_PACIENTES)
        
    def erase(self):
        name = (self.tree.item(self.tree.selection())['values'][0],)
        if name == '':
           messagebox.showwarning(title='Alert', message='Seleccione un elemento')
        else:
            messagebox.showwarning(title='Alert', message='Elemento eliminado')
            run_query(Consultas.ERASE_PACIENTE,name)
            get_data(self.tree, Consultas.GET_DATA)
            
        get_data(self.tree, Consultas.GET_PACIENTES)
        
    def edit_form(self):
        try:
            id_get = self.tree.item(self.tree.selection())['values'][0]
            ci_get = self.tree.item(self.tree.selection())['values'][1]
            nombre_get = self.tree.item(self.tree.selection())['values'][2]
            sexo_get = self.tree.item(self.tree.selection())['values'][3]
            edad_get = self.tree.item(self.tree.selection())['values'][4]
            direccion_get = self.tree.item(self.tree.selection())['values'][5]
            telefono_get = self.tree.item(self.tree.selection())['values'][6]
        except IndexError as e:
            messagebox.showwarning(title='Alert', message='Seleccione un elemento')
            return
        
        self.edit_wind =  Toplevel()
        self.edit_wind.title('Editar paciente') 
        self.edit_wind.geometry('500x600')
        
        
        #Variables 
        self.ci_v= StringVar()
        self.nombre_v = StringVar()
        self.sexo_v = StringVar()
        self.edad_v = StringVar()
        self.direccion_v = StringVar()
        self.telefono_v =  StringVar()
        
        self.ci = Label(self.edit_wind, text= ci_get).pack(expand=True)
        self.ci_entry = Entry(self.edit_wind,textvariable = self.ci_v).pack(fill = X, padx= 20, pady= 10,expand=True)
        
        self.nombre = Label(self.edit_wind, text=nombre_get).pack(expand=True)
        self.nombre_entry = Entry(self.edit_wind,textvariable = self.nombre_v).pack(fill = X, padx= 20, pady= 10,expand=True)
        
        self.sexo = Label(self.edit_wind,text= sexo_get).pack(expand=True)
        self.sexo_entry = Entry(self.edit_wind,textvariable = self.sexo_v).pack(fill = X, padx= 20, pady= 10,expand=True)

        self.edad = Label(self.edit_wind,text= edad_get).pack(expand=True)
        self.edad_entry = Entry(self.edit_wind,textvariable = self.edad_v).pack(fill = X, padx= 20, pady= 10,expand=True)
        
        self.direccion = Label(self.edit_wind,text= direccion_get).pack(expand=True)
        self.direccion_entry = Entry(self.edit_wind,textvariable = self.direccion_v).pack(fill = X, padx= 20, pady= 10,expand=True)
    
        self.telefono = Label(self.edit_wind, text= telefono_get).pack(expand=True)
        self.telefono_entry = Entry(self.edit_wind,textvariable = self.telefono_v).pack(fill = X, padx= 20, pady= 10,expand=True)    
        
        Button(self.edit_wind, text='Editar', font='Arial, 10', command=lambda: self.edit_data(
            self.ci_v.get(),
            self.nombre_v.get(), 
            self.sexo_v.get(), 
            self.edad_v.get(),
            self.direccion_v.get(),
            self.telefono_v.get(), 
            id_get)).pack(side='bottom',fill=X, expand=True, padx=20,pady=20)
    
    def edit_data(self, ci , nombre, sexo, edad, direccion, telefono, id):
        self.ci_data = ci
        self.nombre_data = nombre
        self.sexo_data = sexo
        self.edad_data = edad
        self.direccion_data = direccion
        self.telefono_data = telefono
        self.id_data = id
        
        values = (self.ci_data, self.nombre_data, self.sexo_data, self.edad_data, self.direccion_data, self.telefono_data, self.id_data)
        run_query(Consultas.UPDATE_PACIENTE, values)
        
        get_data(self.tree, Consultas.GET_PACIENTES)
        self.edit_wind.destroy()   
        
    def insert_form(self):
        self.insert_wind =  Toplevel()
        self.insert_wind.title('Insertar paciente') 
        self.insert_wind.geometry('500x500')
        self.insert_wind.resizable(height=False,width=False )
        
        #Variables 
        self.ci_v= StringVar()
        self.nombre_v = StringVar()
        self.sexo_v = StringVar()
        self.edad_v = StringVar()
        self.direccion_v = StringVar()
        self.telefono_v =  StringVar()
        self.enfermedad_id = StringVar()
        
        self.ci = Label(self.insert_wind, text= "Carnet identidad: ").pack(expand=True)
        self.ci_entry = Entry(self.insert_wind,textvariable= self.ci_v).pack(fill = X, padx= 20, pady= 10,expand=True)
        
        self.nombre = Label(self.insert_wind, text="Nombre y apellidos:").pack(expand=True)
        self.nombre_entry = Entry(self.insert_wind,textvariable= self.nombre_v).pack(fill = X, padx= 20, pady= 10,expand=True)
        
        self.sexo = Label(self.insert_wind,text="Sexo:").pack(expand=True)
        self.sexo_entry = Entry(self.insert_wind,textvariable= self.sexo_v).pack(fill = X, padx= 20, pady= 10,expand=True)
    
        self.edad = Label(self.insert_wind, text="Edad:").pack(expand=True)
        self.edad_entry = Entry(self.insert_wind,textvariable= self.edad_v).pack(fill = X, padx= 20, pady= 10,expand=True)    
        
        self.direccion = Label(self.insert_wind, text="Dirección:").pack(expand=True)
        self.direccion_entry = Entry(self.insert_wind,textvariable= self.direccion_v).pack(fill = X, padx= 20, pady= 10,expand=True)    
        
        self.telefono = Label(self.insert_wind, text="Teléfono:").pack(expand=True)
        self.telefono_entry = Entry(self.insert_wind,textvariable= self.telefono_v).pack(fill = X, padx= 20, pady= 10,expand=True)    
        
        self.opciones = run_query(Consultas.COMBO_SELECT)
        
        self.enfermedad_L = Label(self.insert_wind, text= 'Enfermedad:').pack(padx=20, pady= 10, fill= X, expand= True)
        self.enfermedad = ttk.Combobox(self.insert_wind, textvariable= self.enfermedad_id)
        self.enfermedad['values'] = self.opciones
        self.enfermedad.pack(padx = 20, pady = 10, fill= X, expand= True)
        
        Button(self.insert_wind, text='Insertar', font='Arial, 10', command=lambda: self.insert_data(
            self.ci_v.get(),
            self.nombre_v.get(),
            self.sexo_v.get(),
            self.edad_v.get(),
            self.direccion_v.get(),
            self.telefono_v.get(),
            self.enfermedad_id.get())).pack(side='bottom',fill=X, expand=True, padx=20,pady=20)    
    
    def insert_data(self, ci, nombre, sexo, edad, direccion,  telefono, enfermedad_id):
        self.ci_data = ci
        self.nombre_data = nombre
        self.sexo_data = sexo
        self.edad_data= edad
        self.direccion_data = direccion
        self.telefono_data = telefono
        self.enfermedad_id = (enfermedad_id, )
        
        self.id_enfermedad = run_query(Consultas.INSERT_ENFERMEDAD_ID, self.enfermedad_id )
        print(self.id_enfermedad[0][0])
        
        values = (self.ci_data, self.nombre_data, self.sexo_data,self.edad_data, self.direccion_data, self.telefono_data,self.id_enfermedad[0][0] )
        run_query(Consultas.INSERT_PACIENTES, values)
        
        get_data(self.tree, Consultas.GET_PACIENTES)
        
        self.insert_wind.destroy()
        pass
    
""" root = Tk()
root.title("Gmlab Software")
root.resizable(width=True, height=True)
app = FrEnfermedad(root)
app.mainloop() """